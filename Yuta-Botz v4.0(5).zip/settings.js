//base by DGXeon
//re-upload? recode? copy code? give credit ya :)
//YouTube: @DGXeon
//Instagram: unicorn_xeon13
//Telegram: t.me/xeonbotinc
//GitHub: @DGXeon
//WhatsApp: +916909137213
//want more free bot scripts? 
//subscribe to my youtube channel: https://youtube.com/@DGXeon

const fs = require('fs');
const chalk = require('chalk');

//owmner v card
global.ytname = "YT: Leooxzy" //ur yt chanel name
global.socialm = "" //ur github or insta name
global.location = "Indonesia" //ur location

global.welcome = true //welcome/left in groups
global.anticall = false //bot blocks user when called
global.autorecord = true
global.autoswview = false //auto status/story view
global.autoread = false
global.adminevent = true //show promote/demote message
global.groupevent = false //show update messages in group chat

//new
global.botname = 'Yuta-Botz' //ur bot name
global.ownernumber = ['6283136099660'] //ur owner number, dont add more than one
global.ownername = 'Leoo Okkotsu' //ur owner name
global.websitex = ""
global.wagc = "https://whatsapp.com/channel/0029VaG9VfPKWEKk1rxTQD20"
global.saluran = "120363279195205552@newsletter"
global.jidgroupnotif = '120363266755712733@g.us'
global.jidch = '120363279195205552@newsletter'
global.themeemoji = '🪀'
global.wm = "Yuta-Botz"
global.botscript = '' //script link
global.packname = "Yuta-Botz"
global.author = "By Leooxzy"
global.creator = "6283136099660@s.whatsapp.net"
global.xprefix = '.'
global.tiktokname = '@Leooxxzy' //name tiktok owner
global.tiktokname2 = '@celzyundefined' //name tiktok2 owner
global.tiktokname3 = '@LeooxSukaYtmci' //name tiktok3 owner
global.linkch = "https://whatsapp.com/channel/0029VadFS3r89inc7Jjus03W"
global.linkgc = "https://chat.whatsapp.com/JyeT1hdCPJeLy95tzx5eyI"
global.linksosmed = "https://www.tiktok.com/@leooxxzy"
global.version = "v4.0"

global.premium = ["6283136099660"] // Premium User
global.urldb = ''; // kosongin aja tapi kalo mau pake database mongo db isi url mongo
global.sessionName = 'Yuta-Okkotsu'

//bot sett
global.typemenu = 'menubuttonpp' // menu type 'v1' => 'v8'
global.typereply = 'v6' // reply type 'v1' => 'v4'
global.autoblocknumber = '92' //set autoblock country code
global.antiforeignnumber = '91' //set anti foreign number country code

global.ftyuta = [
"https://telegra.ph/file/67def6817bede6ba3cdf1.jpg",
]

global.listv = ['•','●','■','✿','▲','➩','➢','➣','➤','✦','✧','△','❀','○','□','♤','♡','◇','♧','々','〆']
global.tempatDB = 'database.json'

global.limit = {
	free: 100,
	premium: 0,
	vip: 'VIP'
}

global.uang = {
	free: 10000,
	premium: 1000000,
	vip: 10000000
}

global.mess = {
	error: '*[ ᴇʀʀʀᴏʀ ]* Error',
	nsfw: '*[ ɴsғᴡ ]* Nsfw is disabled in this group, Please tell the admin to enable',
	done: 'Done',
	loading: '*[ ʟᴏᴀᴅɪɴɢ ]* Please Wait....'
}

global.bot = {
	limit: 0,
	uang: 0
}

global.game = {
	suit: {},
	menfes: {},
	tictactoe: {},
	kuismath: {},
	tebakbom: {},
}

//~~~~~~~~~~~~~~~< PROCESS >~~~~~~~~~~~~~~~\\

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});